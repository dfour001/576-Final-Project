create function st_mapalgebrafct(rast raster, band integer, onerastuserfunc regprocedure, VARIADIC args text[])
  returns raster
immutable
parallel safe
language sql
as $$
SELECT public.ST_mapalgebrafct($1, $2, NULL, $3, VARIADIC $4)
$$;

alter function st_mapalgebrafct(raster, integer, regprocedure, text [])
  owner to postgres;

