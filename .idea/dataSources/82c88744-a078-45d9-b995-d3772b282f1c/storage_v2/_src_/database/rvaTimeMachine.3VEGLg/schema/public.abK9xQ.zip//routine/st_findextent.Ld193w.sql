create function st_findextent(text, text, text)
  returns box2d
immutable
strict
parallel safe
language plpgsql
as $$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;
BEGIN
	FOR myrec IN EXECUTE 'SELECT public.ST_Extent("' || columnname || '") As extent FROM "' || schemaname || '"."' || tablename || '"' LOOP
		return myrec.extent;
	END LOOP;
END;
$$;

alter function st_findextent(text, text, text)
  owner to postgres;

