create function st_valuecount(rastertable text, rastercolumn text, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, searchvalues double precision[] DEFAULT NULL::double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT count integer)
  returns SETOF record
stable
language sql
as $$
SELECT value, count FROM public._ST_valuecount($1, $2, $3, $4, $5, $6)
$$;

comment on function st_valuecount(text, text, integer, boolean, double precision [], double precision,
  out                             double precision, out integer)
is 'args: rastertable, rastercolumn, nband=1, exclude_nodata_value=true, searchvalues=NULL, roundto=0, OUT value, OUT count - Returns a set of records containing a pixel band value and count of the number of pixels in a given band of a raster (or a raster coverage) that have a given set of values. If no band is specified defaults to band 1. By default nodata value pixels are not counted. and all other values in the pixel are output and pixel band values are rounded to the nearest integer.';

alter function st_valuecount(text, text, integer, boolean, double precision [], double precision, out double precision, out integer)
  owner to postgres;

