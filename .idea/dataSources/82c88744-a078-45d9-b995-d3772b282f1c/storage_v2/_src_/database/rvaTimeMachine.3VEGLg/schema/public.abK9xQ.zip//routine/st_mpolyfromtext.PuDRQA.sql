create function st_mpolyfromtext(text)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'MULTIPOLYGON'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

comment on function st_mpolyfromtext(text)
is 'args: WKT - Makes a MultiPolygon Geometry from WKT with the given SRID. If SRID is not given, it defaults to 0.';

alter function st_mpolyfromtext(text)
  owner to postgres;

