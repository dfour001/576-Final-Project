create function st_value(rast raster, x integer, y integer, exclude_nodata_value boolean DEFAULT true)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT st_value($1, 1, $2, $3, $4)
$$;

comment on function st_value(raster, integer, integer, boolean)
is 'args: rast, x, y, exclude_nodata_value=true - Returns the value of a given band in a given columnx, rowy pixel or at a particular geometric point. Band numbers start at 1 and assumed to be 1 if not specified. If exclude_nodata_value is set to false, then all pixels include nodata pixels are considered to intersect and return value. If exclude_nodata_value is not passed in then reads it from metadata of raster.';

alter function st_value(raster, integer, integer, boolean)
  owner to postgres;

